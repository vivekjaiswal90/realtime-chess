<? /* ***** PASSWORDS ***** */
$passwords = array ( 
  "guest" => "guest",
  "guest2" => "guest",
);
/* ***** MAIL-ADDRESSES ***** */
$mail_addresses = array (
  "guest" => "dummy@nowhere.org",
  "guest2" => "someone@world.net"
); ?>
