<? $credits='The chessmen graphics were taken from <A class="tiny" href="http://www.tommasovitale.it/my/wcg">WCG</A> with kind permission of Tommaso Vitale.';?>

