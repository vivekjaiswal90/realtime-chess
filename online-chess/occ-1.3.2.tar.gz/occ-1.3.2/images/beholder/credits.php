<? $credits='The chessmen graphics were taken from <A class="sublink" href="http://sourceforge.net/projects/webchess/">WebChess</A>.';?>

